package com.example.alesraaprojectxml;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MassageTheAdmin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_massage_the_admin);
    }
}